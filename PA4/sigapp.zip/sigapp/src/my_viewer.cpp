﻿
# include "my_viewer.h"
# include <sigogl/ui_button.h>
# include <sigogl/ui_radio_button.h>
# include <sig/sn_primitive.h>
# include <sig/sn_transform.h>
# include <sig/sn_manipulator.h>
# include <sigogl/ws_run.h>

double seconds = 0.0f;
//References: TA, Jefferson Santiago.
//The code is built from what the TA has helped with during Labs and help by others.
MyViewer::MyViewer ( int x, int y, int w, int h, const char* l ) : WsViewer(x,y,w,h,l)
{
	_nbut=0;
	_animating=false;
	build_ui ();
	build_scene ();
	output("Hello there human :) \nPressing Keys:\n\
			'q' = Faces++\n\
			'a' = Faces--\n\
			'w' = r++\n\
			's' = r--\n\
			'e' = R++\n\
			'd' = R--\n\
			'z' = Flat Shading\n\
			'x' = Smooth Shading\n\
			'c' = View Normals\n\
			'v' = Hide Normals");
}

void MyViewer::build_ui ()
{
	UiPanel* p, *sp;
	UiManager* uim = WsWindow::uim();
	p = uim->add_panel ( "", UiPanel::HorizLeft );
	p->add ( new UiButton ( "Shading", sp=new UiPanel() ) );
	{	UiPanel* p=sp;
		p->add ( new UiButton ( "Flat", EvFlat ) ); 
		p->add(new UiButton("Smooth", EvSmooth));
	}
	//p->add ( new UiButton ( "Animate", EvAnimate ) );
	p->add(new UiButton("Normals", EvNormals));
	p->add(new UiButton("Color", sp = new UiPanel()));
	{	UiPanel* p = sp;
	p->add(new UiButton("Red", EvRed));
	p->add(new UiButton("Blue", EvBlue));	
	p->add(new UiButton("Green", EvGreen));
	p->add(new UiButton("Random", EvRandom));
	}
	p->add(new UiButton("Animate", EvAnimate));
	p->add ( new UiButton ( "Exit", EvExit ) ); p->top()->separate();
}

//void MyViewer::add_model(SnShape* s, GsVec p)
//{}

void MyViewer::build_scene()
{
	torus = new SnModel;
	theta = phi = (float)gs2pi;
	center.remove(0, center.size());
	GsPnt P1, P2, P3, P4;
	int index = 0;
	torus->model()->init();
	int start = index;
	for (float theta1 = 0.0f; theta1 < theta; theta1 += theta / n) {

		for (float phi2 = 0.0f; phi2 < phi; phi2 += phi / n) {
			start = index;
			//Using the equation given from the guidelines.
			P1.set(
				(R + r * cosf(theta1)) * cosf(phi2),
				(R + r * cosf(theta1)) * sinf(phi2),
				r * sinf(theta1)
			);
			torus->model()->V.push(P1);
			index++;
			P2.set(
				(R + r * cosf(theta1 + (theta / n))) * cosf(phi2),
				(R + r * cosf(theta1 + (theta / n))) * sinf(phi2),
				r * sinf(theta1 + (theta / n))
			);
			torus->model()->V.push(P2);
			index++;

			P3.set(
				(R + r * cosf(theta1 + (theta / n))) * cosf(phi2 + (phi / n)),
				(R + r * cosf(theta1 + (theta / n))) * sinf(phi2 + (phi / n)),
				r * sinf(theta1 + (theta / n))
			);
			torus->model()->V.push(P3);
			index++;
			P4.set(
				(R + r * cosf(theta1)) * cosf(phi2 + (phi / n)),  //X
				(R + r * cosf(theta1)) * sinf(phi2 + (phi / n)),	//Y
				r * sinf(theta1)	//Z
			);
			torus->model()->V.push(P4);
			index++;

			//Reversed the face coordinates to get the normals to face out not in.
			torus->model()->F.push(GsModel::Face(start, start + 2, start + 1));
			torus->model()->F.push(GsModel::Face(start, start + 3, start + 2));

			//Calculates centers for the smooth shading.
			//With the help of Jefferson Santiago.
			float x0 = (R * cosf(phi2));
			float y0 = (R * sinf(phi2));
			
			center.push(GsPnt(x0, y0, 0.0f));
			center.push(GsPnt(x0, y0, 0.0f));

			//float offset = i + ((float)gs2pi / n);
			x0 = (R * cosf(phi2 + (gs2pi / n)));
			y0 = (R * sinf(phi2 + (gs2pi / n)));
			center.push(GsPnt(x0, y0, 0.0f));
			center.push(GsPnt(x0, y0, 0.0f));
		}
	}
	torus->color(color);
	rootg()->add(torus);
	shade();
	
}

void MyViewer::run_animation()
{
	output("ANIMATING!");
	double frames = 1 / 60.0f;
	double t0 = gs_time(), t = 0.0f, tf = 0.0f;
	seconds = 0;
	int counter = 0;
	do
	{
		if (_animating == false)break;
		while (t - tf < frames) {
			ws_check();
			t = (gs_time() - t0);
		}

		tf = t;
		seconds++;
		if (counter % 60 == 0) {
			uievent(EvRandom);
		}
		counter += 1 / 60;
		render();
		ws_check();
		if (seconds == 60) break;

	} while (true);

	_animating = false;
	output("Finished Animating!");
}

void MyViewer::shade() {
	GsVec V, V2;
	torus->model()->N.remove(0, torus->model()->N.size());
	if (S) {
		//Provided by the TA, followed his technique.		
		int x, y, z;
		for (int i = 0; i < torus->model()->F.size(); i++) {
			x = torus->model()->F[i].a;
			y = torus->model()->F[i].b;
			z = torus->model()->F[i].c;

			V = torus->model()->V[x] - torus->model()->V[y];
			normalize(V);
			V2 = torus->model()->V[z] - torus->model()->V[y];
			normalize(V2);
			torus->model()->N.push(cross(V2, V));
		}
		torus->model()->set_mode(GsModel::Flat, GsModel::NoMtl);
	}
	if (!S) {
		for (int i = 0; i < torus->model()->V.size(); i++) {
			torus->model()->N.push(normalize((torus->model()->V[i] - center[i])));
		}
		torus->model()->set_mode(GsModel::Smooth, GsModel::NoMtl);

	}
	render();

}

void MyViewer::compute_segments(bool flat) {
	rootg()->remove(l);
	l = new SnLines;
	l->init();
	l->color(GsColor::white);
		//Provided by the PA4 PDF.
	if (flat) {
		GsModel& m = *torus->model();
		for (int i = 0; i < m.F.size(); i++) {
			const GsVec& a = m.V[m.F[i].a];
			const GsVec& b = m.V[m.F[i].b];
			const GsVec& c = m.V[m.F[i].c];
			const GsVec& fcenter = (a + b + c) / 3.0f;
			l->push(fcenter, fcenter + (m.N[i] * 5.0f));

		}
	}
	else {
		GsModel& m = *torus->model();
		for (int i = 0; i < m.V.size(); i++) {
			const GsVec& fcenter = m.V[i];
			l->push(fcenter, fcenter + (m.N[i]*0.03f));
		}
	}
		l->line_width(2.0f);
		rootg()->add(l);
		render();
}
int MyViewer::handle_keyboard ( const GsEvent &e )
{
	int ret = WsViewer::handle_keyboard ( e ); // 1st let system check events
	if ( ret ) return ret;
	//GsMat rot;
	//will determine how fast each interaction is. Lower is bigger.
	//float speed = 100;
	switch (e.key)
	{
	case GsEvent::KeyEsc: gs_exit(); return 1;

	case 'q': {
		if (n > 0) {
			n += 2;
			rootg()->remove_all();
			build_scene();
			compute_segments(S);
			l->visible(norm);
			output("Updating");
		}
		return 1;
	}
	case 'a': {
		if (n > 4) {
			n -= 2;
			rootg()->remove_all();
			build_scene();
			compute_segments(S);
			l->visible(norm);
			output("Updating");
		}
		return 1;
	}
	case 'w': {
		r += 0.05f;
		rootg()->remove_all();
		build_scene();
		compute_segments(S);
		l->visible(norm);
		output("Updating");
		return 1;
	}
	case 's': {
		if (r > 0.05f) {
			r -= 0.05f;
			rootg()->remove_all();
			build_scene();
			compute_segments(S);
			l->visible(norm);
			output("Updating");
		}
		return 1;
	}
	case 'e': {
		if (R > 0.0f) {
			R += 0.05f;
			rootg()->remove_all();
			build_scene();
			compute_segments(S);
			l->visible(norm);
			output("Updating");
		}
		return 1;

	}
	case 'd': {
		if (R > 0.1f) {
			R -= 0.05f;
			rootg()->remove_all();
			build_scene();
			compute_segments(S);
			l->visible(norm);
			output("Updating");
		}
		return 1;
	}
	case 'z': {
		S = true;
		shade();
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case 'x': {
		S = false;
		shade();
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case 'c': {
		norm = true;	
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case 'v': {
		norm = false;
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	default: output("Hello there human:) \nPressing Keys:\n\
			'q' = Faces++\n\
			'a' = Faces--\n\
			'w' = r++\n\
			's' = r--\n\
			'e' = R++\n\
			'd' = R--\n\
			'z' = Flat Shading\n\
			'x' = Smooth Shading\n\
			'c' = View Normals\n\
			'v' = Hide Normals");
		return 1;
}
	return 0;
}

int MyViewer::uievent ( int e )
{
	switch ( e )
	{
	case EvFlat: {
		S = true;
		shade();
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case EvSmooth: { 
		S = false;
		shade(); 
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case EvNormals: {
		if (norm == false) norm = true;
		else norm = false;
		
		if (norm == true) {
				compute_segments(S);
			}
		l->visible(norm);
		return 1;
	}
	case EvRed: {
		color = GsColor::darkred;
		rootg()->remove_all();
		build_scene();
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case EvBlue: {
		color = GsColor::darkblue;
		rootg()->remove_all();
		build_scene();
		compute_segments(S);
		l->visible(norm);		
		return 1;
	}
	case EvGreen: {
		color = GsColor::darkgreen;
		rootg()->remove_all();
		build_scene();
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case EvRandom: {
		color = GsColor::random();
		rootg()->remove_all();
		build_scene();
		compute_segments(S);
		l->visible(norm);
		return 1;
	}
	case EvAnimate: _animating = true; run_animation(); return 1;
	case EvExit: gs_exit();
	}
	return WsViewer::uievent(e);
}
